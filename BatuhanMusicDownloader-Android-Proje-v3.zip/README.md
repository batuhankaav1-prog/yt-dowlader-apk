# Batuhan Music Downloader

Android Studio ile açılabilen Android projesi.

## Bu sürümde çalışanlar
- Birden fazla doğrudan HTTP/HTTPS ses dosyası bağlantısını satır satır girme
- Android DownloadManager ile indirmeleri kuyruğa alma
- İndirmeleri Bildirimler bölümünden takip etme
- Dosyaları Downloads klasörüne kaydetme
- Android 6.0+ hedefi; Android 11 / Redmi Note 8 Pro uyum hedefi

## Sınırlar
- YouTube video veya playlist URL'sinden MP3 çıkarmaz. YouTube URL'si doğrudan medya dosyası bağlantısı değildir; YouTube'un indirme/erişim korumalarını aşmaz.
- Bu sürüm MP3 dönüştürme yapmaz; kaynak dosyayı olduğu gibi indirir. 320 kbps seçeneği, düşük kaliteli kaynağı gerçek 320 kbps kaliteye yükseltemez.
- Yalnızca indirme izni olan, doğrudan medya dosyası bağlantılarını kullanın.

## APK oluşturma
1. Android Studio'da proje klasörünü aç.
2. Gradle senkronizasyonunu tamamla.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK: `app/build/outputs/apk/debug/app-debug.apk`

Not: Bu çalışma ortamında Android SDK/Gradle derlemesi yapılmadı; ZIP proje kaynaklarını içerir, hazır APK değildir.
