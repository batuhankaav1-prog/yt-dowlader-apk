package com.batuhan.musicdownloader;

import android.app.Activity;
import android.app.DownloadManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.*;
import java.net.URL;
import java.net.HttpURLConnection;
import java.util.Locale;

public class MainActivity extends Activity {
    private EditText urlInput;
    private TextView status;
    private DownloadManager manager;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        getWindow().setStatusBarColor(Color.rgb(16,24,39));
        getWindow().setNavigationBarColor(Color.rgb(16,24,39));

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 28);
        root.setBackgroundColor(Color.rgb(16,24,39));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("♫  Batuhan Music Downloader");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Doğrudan medya bağlantılarını toplu indir");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(14);
        subtitle.setPadding(0, 12, 0, 24);
        root.addView(subtitle);

        TextView label = new TextView(this);
        label.setText("Ses dosyası bağlantıları");
        label.setTextColor(Color.WHITE);
        label.setTextSize(16);
        root.addView(label);

        urlInput = new EditText(this);
        urlInput.setHint("Her satıra bir doğrudan MP3 / ses dosyası URL'si yapıştır");
        urlInput.setTextColor(Color.WHITE);
        urlInput.setHintTextColor(Color.GRAY);
        urlInput.setMinLines(4);
        urlInput.setGravity(android.view.Gravity.TOP);
        urlInput.setPadding(16, 12, 16, 12);
        urlInput.setBackgroundColor(Color.rgb(35,45,62));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(-1, -2);
        inputParams.topMargin = 12;
        root.addView(urlInput, inputParams);

        TextView quality = new TextView(this);
        quality.setText("İndirilen dosya: kaynak biçiminde korunur");
        quality.setTextColor(Color.rgb(134,239,172));
        quality.setTextSize(14);
        quality.setPadding(0, 18, 0, 18);
        root.addView(quality);

        Button download = new Button(this);
        download.setText("İndirmeyi başlat");
        download.setAllCaps(false);
        download.setTextColor(Color.WHITE);
        download.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(22,163,74)));
        root.addView(download, new LinearLayout.LayoutParams(-1, -2));

        status = new TextView(this);
        status.setText("Hazır. Yalnızca indirme iznin olan doğrudan medya bağlantılarını kullan.");
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(14);
        status.setPadding(0, 22, 0, 0);
        root.addView(status);

        TextView note = new TextView(this);
        note.setText("Kullanım: Her satıra bir doğrudan ses dosyası bağlantısı ekle. İndirmeler telefonunun Downloads klasörüne kaydedilir. Bu uygulama YouTube bağlantılarından ses çıkarmaz; YouTube playlist URL'si doğrudan medya dosyası değildir. 320 kbps dönüştürme bu sürümde yoktur; mevcut ses kalitesi korunur.");
        note.setTextColor(Color.rgb(203,213,225));
        note.setTextSize(12);
        note.setPadding(0, 14, 0, 0);
        root.addView(note);

        download.setOnClickListener(v -> startDownloads());
        setContentView(scroll);
    }

    private void startDownloads() {
        if (android.os.Build.VERSION.SDK_INT < 29 && checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            status.setText("Depolama izni verdikten sonra tekrar dene.");
            return;
        }
        String raw = urlInput.getText().toString().trim();
        if (raw.isEmpty()) {
            status.setText("Önce en az bir bağlantı gir.");
            return;
        }
        String[] lines = raw.split("\\r?\\n");
        int started = 0, rejected = 0;
        for (String line : lines) {
            String s = line.trim();
            if (s.isEmpty()) continue;
            try {
                Uri uri = Uri.parse(s);
                String scheme = uri.getScheme();
                if (!("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) || uri.getHost() == null) {
                    rejected++;
                    continue;
                }
                String last = uri.getLastPathSegment();
                if (last == null || last.trim().isEmpty()) last = "audio-" + System.currentTimeMillis() + ".mp3";
                last = last.replaceAll("[^A-Za-z0-9._-]", "_");
                DownloadManager.Request request = new DownloadManager.Request(uri);
                request.setTitle(last);
                request.setDescription("Batuhan Music Downloader");
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setAllowedOverMetered(true);
                request.setAllowedOverRoaming(false);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, last);
                manager.enqueue(request);
                started++;
            } catch (Exception e) {
                rejected++;
            }
        }
        status.setText(String.format(Locale.getDefault(),
                "%d indirme kuyruğa eklendi. %d bağlantı geçersiz göründüğü için atlandı. İlerlemeyi bildirimlerden takip edebilirsin.",
                started, rejected));
    }
}
